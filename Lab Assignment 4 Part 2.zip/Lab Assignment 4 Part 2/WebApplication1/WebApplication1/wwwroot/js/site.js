﻿document.addEventListener('DOMContentLoaded', function () {
    var holidayForm = document.getElementById('holidayForm');
    holidayForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var country = document.getElementById('txtCountryCode').value;
        var year = document.getElementById('txtYear').value;
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.open('GET', '/Home/Index?countryCode=' + country + '&year=' + year, true);
        xmlHttp.onreadystatechange = function () {
            if (xmlHttp.readyState == XMLHttpRequest.DONE) {
                if (xmlHttp.status == 200) {
                    var tableE = document.createElement('div');
                    tableE.innerHTML = xmlHttp.responseText;
                    var table = tableE.querySelector('.table.table-bordered.table-striped.table-sm');
                    document.getElementById('holidayResults').innerHTML = table.outerHTML;
                }
                else {
                    console.error('There was an error while loading the page:', xmlHttp.statusText);
                }
            }
        };
        xmlHttp.send();
    });
});