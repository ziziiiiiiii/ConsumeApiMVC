﻿using System.Text.Json;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public interface IHolidaysApiService
    {
        Task<List<HolidayModel>> GetHolidays(string countryCode, int year);
    }
}